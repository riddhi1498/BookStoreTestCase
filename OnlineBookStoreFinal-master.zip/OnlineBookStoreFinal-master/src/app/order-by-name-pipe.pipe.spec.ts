import { OrderByNamePipePipe } from './order-by-name-pipe.pipe';

describe('OrderByNamePipePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderByNamePipePipe();
    expect(pipe).toBeTruthy();
  });
});
